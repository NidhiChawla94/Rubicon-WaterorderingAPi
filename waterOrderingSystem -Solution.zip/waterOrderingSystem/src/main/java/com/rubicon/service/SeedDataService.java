package com.rubicon.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.rubicon.model.Order;
import com.rubicon.model.OrderStatus;


/**
 * This class creates dummy data when controller is created by main class
 * **/
public class SeedDataService {
    private static SeedDataService single_instance = null; 
  
    private List<Order> seedData = new ArrayList<>(); 
  
   
    private SeedDataService() 
    { 
        seedData.add(new Order("1", LocalDateTime.of(2020, 02, 24, 11, 40), 2, OrderStatus.Requested ));
        seedData.add(new Order("2", LocalDateTime.of(2020, 02, 24, 11, 41), 1, OrderStatus.Cancelled ));
        seedData.add(new Order("3", LocalDateTime.of(2020, 02, 24, 12, 42), 3, OrderStatus.Requested ));
        seedData.add(new Order("4", LocalDateTime.of(2020, 02, 24, 11, 43), 5, OrderStatus.Requested ));
    } 
  
    // static method to create instance of Singleton class 
    public static SeedDataService getInstance() 
    { 
        if (single_instance == null) 
            single_instance = new SeedDataService(); 
  
        return single_instance; 
    } 
    public List<Order> getSeedData() {
    	return this.seedData;
    }
}
