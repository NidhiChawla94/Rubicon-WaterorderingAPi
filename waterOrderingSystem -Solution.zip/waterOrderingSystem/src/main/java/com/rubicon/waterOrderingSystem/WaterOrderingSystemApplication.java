package com.rubicon.waterOrderingSystem;

import java.util.List;
import java.util.Map;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.rubicon.controller.OrderController;
import com.rubicon.model.Order;

@SpringBootApplication
@RestController
@EnableScheduling
@Component
public class WaterOrderingSystemApplication {
	private static OrderController controller;
	public static void main(String[] args) {
		
		controller = new OrderController();
		SpringApplication.run(WaterOrderingSystemApplication.class, args);
	}

	/**
	 * Scheduler which runs every 1 minute. to check if there are any new orders to process.
	 * **/
	
	@Scheduled(fixedRate = 60000)
	public void processOrderScheduler() {
		controller.processOrders();
	}
	/**
	 * This API will return all the orders for the given farmId
	 * If the farmId is null or empty it will throw error or if no data for the given farmId is found it will send no_content response.
	 * **/
	@GetMapping("/getExistingOrder")
	public List<Order> getExistingOrder(@RequestParam(value = "farmId")String farmId){
		if(farmId == null || farmId.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid farmId");
		}
		else {
			List<Order> existingOrders = controller.getExistingOrder(farmId);
			if(existingOrders.size() == 0) {
				throw new ResponseStatusException(HttpStatus.NO_CONTENT, "No details found for this farm id");
			}
			else {
				return existingOrders;
			}
		}	
	}
	/**
	 * This API will cancel the order sent in the request.
	 * If the order is null it will throw bad request
	 * if the order is not found or the order is not in requested state then it will throw no content response
	 * **/
	@PostMapping("/cancelOrder")
	public <T> ResponseEntity<T> cancelOrder(@RequestBody Order order) {
		if(order == null) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid farmId");
		}
		else {
			boolean success =controller.cancelOrder(order);
			if(success) {
				
				return new ResponseEntity<>(HttpStatus.OK);
			}
			else {
				throw new ResponseStatusException(HttpStatus.NO_CONTENT, "Could not cancel the order.");
			}
		}
	}
	
	/**
	 * The API adds order to the list of existing orders.
	 * If successfully added it returns ok status else throws errors 
	 * */
	@PostMapping("/addOrder")
	public <T> ResponseEntity<T> addOrder(@RequestBody Map<String, Object> orderDetails) {
		boolean farmIdValid = orderDetails.containsKey("farmId") && !(orderDetails.get("farmId").toString().isEmpty() || orderDetails.get("farmId").toString() == null); 
		boolean orderDateValid = orderDetails.containsKey("orderDate") && !(orderDetails.get("orderDate").toString().isEmpty() || orderDetails.get("orderDate").toString() == null);
		boolean durationValid = orderDetails.containsKey("duration") && !(orderDetails.get("duration").toString().isEmpty() || orderDetails.get("duration").toString() == null);
		if(farmIdValid && orderDateValid && durationValid ) {
			boolean success =controller.addOrder(orderDetails);
			if(success) {
				return new ResponseEntity<>(HttpStatus.OK);
			}
			else {
				throw new ResponseStatusException(HttpStatus.ALREADY_REPORTED, "You have already ordered water for the farm for the same time. ");
			}
		}
		else {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid farmId");
		}
		
	}
}
