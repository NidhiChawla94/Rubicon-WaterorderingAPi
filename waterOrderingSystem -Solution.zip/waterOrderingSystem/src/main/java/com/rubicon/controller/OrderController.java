package com.rubicon.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.rubicon.model.Order;
import com.rubicon.model.OrderStatus;
import com.rubicon.service.SeedDataService;

public class OrderController {

	private List<Order> orders;
	public OrderController() {
		orders = new ArrayList<Order>();
		orders = SeedDataService.getInstance().getSeedData();
	}
	
	/**
	 * This function will add order to the list or orders
	 * The order will only be added if there is no overlapping between that new order details and existing order 
	 * which means for the same farmid, water should not have been ordered before for the same time and date or for overlapping times.
	 * 
	 * @param Map<String, object> orderDetails: details of new order
	 * @return boolean
	 * **/
	public boolean addOrder(Map<String, Object> orderDetails) {
		boolean isNewOrderAllowed = true;
		isNewOrderAllowed = checkWaterOrderOverlapping(orderDetails);
		if(isNewOrderAllowed) {
			Order newOrder = new Order(orderDetails.get("farmId").toString(), 
					LocalDateTime.parse(orderDetails.get("orderDate").toString()), 
					Integer.parseInt(orderDetails.get("duration").toString()), 
					OrderStatus.Requested);		
			newOrder.setOrderId(orders.size()+1);
			orders.add(newOrder);
			System.out.println("Order for the farm: "+ newOrder.getFarmId() + " is added");
		}
		return isNewOrderAllowed;
	}
	/**
	 * The function checks if there is a overlapping of timings between the given order details and exiting orders.
	 * It checks for the given farm, then compares dates and then the time.
	 * The new orderDetails should finish before existing order or start after existing order.
	 * 
	 @param Map<String, object> orderDetails: details of new order
	 *@return boolean
	 * **/
	private boolean checkWaterOrderOverlapping(Map<String, Object> orderDetails) {
		boolean isOrderAllowed = true;
		for(Order existingOrderItr: orders) {
			
			LocalDateTime newOrderStartDateTime = LocalDateTime.parse(orderDetails.get("orderDate").toString());
			LocalDateTime existingStartDateTime = existingOrderItr.getOrderDateTime();
			
			if((existingOrderItr.getFarmId().equals(orderDetails.get("farmId").toString())) && (newOrderStartDateTime.getMonth() == existingStartDateTime.getMonth() && newOrderStartDateTime.getYear() == existingStartDateTime.getYear() && newOrderStartDateTime.getDayOfMonth()== existingStartDateTime.getDayOfMonth())) {
				LocalDateTime existingOrderFinishingTime = existingOrderItr.getOrderFinishDateTime();
				LocalDateTime newOrderFinishingTime = newOrderStartDateTime.plusMinutes(Integer.parseInt(orderDetails.get("duration").toString()));
				
				if(!(existingStartDateTime.compareTo(newOrderFinishingTime)>= 0  || newOrderStartDateTime.compareTo(existingOrderFinishingTime)>= 0)) {
					isOrderAllowed = false; 
					break;
				} 
			}
			
			
		}
		return isOrderAllowed;
	}

	/**
	 * The function below cancels the given order if the status is Requested.
	 * 
	 * @param Order order: order to be cancelled
	 * @return boolean: order successfully cancelled
	 * **/
	public boolean cancelOrder(Order order) {
		Order orderObj = orders.stream()
				  .filter(orderItr -> orderItr.getFarmId().equals(order.getFarmId()))
				  .findAny()
				  .orElse(null);
		if(orderObj != null && orderObj.getStatus().equals(OrderStatus.Requested)) {
			System.out.println("Order of farm id : "+ order.getFarmId() +" for " + order.getOrderDateTime() + "is cancelled");
			orderObj.setStatus(OrderStatus.Cancelled);
			return true;
		}
		return false;
	}
	
	/**
	 * The function returns orders of the given farm id.
	 * 
	 * @param String farmId: farmId for which orders have to retrieved
	 * @return List<Order>: list of orders for the given farm
	 * **/
	public List<Order> getExistingOrder(String farmId) {
		List<Order> existingOrders = new ArrayList<Order>();
		for(Order orderItr : orders) {
			if(orderItr.getFarmId().equals(farmId)) {
				existingOrders.add(orderItr);
			}
		}
		return existingOrders;
	}
	
	/**
	 * This function gets called by the scheduler to process the orders.
	 * **/
	public void processOrders() {
		System.out.println();
		System.out.println();
		for(Order orderItr: orders) {
			
			if(!orderItr.getStatus().equals(OrderStatus.Cancelled )) {
				
				/**
				 * Checking whether the current time matches the requested order time is done to minute and hour level.
				 * Therefore to ignore the comparison of time at second and millisecond we are making current second and millisecond equal to the requested millesecond and second.
				 * **/
				LocalDateTime dateTimeNow = LocalDateTime.now().withSecond(orderItr.getOrderDateTime().getSecond()).withNano(orderItr.getOrderDateTime().getSecond());
				LocalDateTime existingOrderStartDateTime = orderItr.getOrderDateTime();
				
				if((dateTimeNow.getMonth() == existingOrderStartDateTime.getMonth() && dateTimeNow.getYear() == existingOrderStartDateTime.getYear() && dateTimeNow.getDayOfMonth()== existingOrderStartDateTime.getDayOfMonth())) {
					LocalDateTime existingOrderFinishingTime = orderItr.getOrderFinishDateTime();
	
					if(existingOrderStartDateTime.compareTo(dateTimeNow) == 0) {
						orderItr.setStatus(OrderStatus.InProgress);
						System.out.println("Water delivery to farm "+ orderItr.getFarmId()+ " started");
					}
					if(existingOrderFinishingTime.compareTo(dateTimeNow)== 0) {
						orderItr.setStatus(OrderStatus.Delivered);
						System.out.println("Water delivery to farm "+ orderItr.getFarmId()+ " finished");
					}
				}
			}
			
			
		}
	
	}
}
