package com.rubicon.model;

/**
 * enum to store possible status of an order
 * **/
public enum OrderStatus {

	Requested,
	InProgress,
	Delivered,
	Cancelled
}
