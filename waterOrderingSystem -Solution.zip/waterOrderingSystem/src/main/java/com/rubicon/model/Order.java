package com.rubicon.model;

import java.time.LocalDateTime;
/**
 * Order model class.
 * */
public class Order {
	private int orderId;
	private String farmId;
	private LocalDateTime orderDateTime;
	private int durationMins;
	private OrderStatus status;
	
	public Order() {
		super();
	}
	public Order(String farmId, LocalDateTime orderDateTime, int durationMins, OrderStatus status) {
		super();
		this.farmId = farmId;
		this.orderDateTime = orderDateTime;
		this.status = status;
		this.durationMins = durationMins;
	}
	public LocalDateTime getOrderFinishDateTime() {
		return this.orderDateTime.plusMinutes(this.durationMins);
		
	}
	public String getFarmId() {
		return farmId;
	}
	public OrderStatus getStatus() {
		return status;
	}
	public LocalDateTime getOrderDateTime() {
		return orderDateTime;
	}
	
	public void setStatus(OrderStatus status) {
		this.status = status;
	}
	public int getDuration() {
		return durationMins;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	
}
