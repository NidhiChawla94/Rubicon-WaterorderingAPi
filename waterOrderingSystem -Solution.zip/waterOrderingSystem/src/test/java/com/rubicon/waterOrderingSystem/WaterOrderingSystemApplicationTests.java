package com.rubicon.waterOrderingSystem;

import org.junit.jupiter.api.Test;


class WaterOrderingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
